/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exa02.dao;

import exa02.model.Venta;
import java.util.List;
import java.util.Map;

/**
 *
 * @author JC
 */
public interface VentaDao {
    int create (Venta v);
    List<Map<String , Object>> readdAll();
}
