/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exa02.dao;

import exa02.model.Usuario;
import java.util.List;
import java.util.Map;

/**
 *
 * @author JC
 */
public interface UsuarioDao {
    int create(Usuario usuario);
    
    int update(Usuario usuario);
    
    int delete(int idusuario);
    
    Usuario read(int idusuario);
    List<Map<String , Object>> readAll();
    
}
