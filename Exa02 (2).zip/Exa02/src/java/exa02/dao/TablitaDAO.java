/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exa02.dao;

import java.util.List;
import exa02.model.Tablita;
import java.util.Map;

/**
 *
 * @author alarc
 */
public interface TablitaDAO {
    int create(Tablita tabla);

    int update(Tablita taba);

    int delete(int idtabla);

    Tablita read(int idtabla);
    List<Map<String , Object>> readAll();
}
