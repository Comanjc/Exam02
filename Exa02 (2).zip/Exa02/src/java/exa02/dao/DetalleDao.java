/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exa02.dao;

import exa02.model.Detalle;

/**
 *
 * @author JC
 */
public interface DetalleDao {
    int create (Detalle d);
}
