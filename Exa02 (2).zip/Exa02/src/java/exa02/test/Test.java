package exa02.test;

import com.google.gson.Gson;
import exa02.config.Conexion;



public class Test {

    static Gson g = new Gson();
    /**
     * @param args the command line arguments
     */
    static Gson gson = new Gson();


    public static void main(String[] args) {

        if (Conexion.getConexion() != null) {
            System.out.println("si");

        } else {
            System.out.println("no");
        }

    }

}
