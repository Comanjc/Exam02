/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exa02.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author JC
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Usuario {
    private int idusuario;
    private String usermane;
    private String password;
    private int estado;
    private int idrol;
    private int idempleado;
}
