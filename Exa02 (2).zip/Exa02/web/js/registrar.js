$(document).ready(function (){
   listarregistro(); 
});



