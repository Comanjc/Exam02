$(document).ready(function () {
    listarSucursales();

});
function listarSucursales() {
    $.get("unosucursal", {"opc": 1}, function (data) {
        let x = JSON.parse(data);
        x.forEach((item) => {
            $("#sucursal").append("<option value='" + item.idsucursal + "'>" + item.nombre + "</option>");
        });
    });
}

