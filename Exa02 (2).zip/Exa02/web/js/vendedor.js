$(document).ready(function () {

    listarvendedor();
});

function listarvendedor() {
    $.get("usuario", {"opc": 1}, function (data) {

        let x = JSON.parse(data);
        for (let i = 0; i < x.length; i++) {
            $("#vendedor").append("<option>" + x[i].user + "</option>");
        }

    });
}

