$(document).ready(function () {
    listarProducto();


});
var precio;
function listarProducto() {
    $.get("producto", {"opc": 1}, function (data) {
        let x = JSON.parse(data);
        precio = x;
        for (let i = 0; i < x.length; i++) {
            $("#productos").append($("<option>", {
                value: x[i].idproducto,
                text: x[i].nombre
            })
                    );
        }

    });

}
let mostrar = () => {
    var selected = $("#productos :selected").val();
    precio.forEach(function (elemento) {
        if (elemento.idproducto == selected) {
            $("#Productos").val(elemento.nombre);
            $("#precio").val("$ " + elemento.precio);
            $("#stock").val(elemento.stock);
        }
    });
};

$("#agregar").click(mostrar);
 
