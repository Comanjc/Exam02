$(document).ready(function () {
    listarClientes();
});

function listarClientes() {
    $.get("cliente", {"opc": 1}, function (data)
    {
        let x = JSON.parse(data);
        for (let i = 0; i < x.length; i++) {
            $("#cliente").append($("<option>", {
                value: x[i],
                text: x[i].nombre

            })
                    );
        }

    });
}


